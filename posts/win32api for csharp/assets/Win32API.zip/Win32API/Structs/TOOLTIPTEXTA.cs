// ---------------------------------------------------------
// FileName: TOOLTIPTEXTA.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;

namespace Win32API.Structs
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct TOOLTIPTEXTA
    {
        public NMHDR hdr;
        public IntPtr lpszText;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string szText;

        public IntPtr hinst;
        public int uFlags;
    }
}
