// ---------------------------------------------------------
// FileName: TreeViewMessages.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum TreeViewMessages
    {
        TV_FIRST = 0x1100,
        TVM_GETITEMRECT = TV_FIRST + 4,
        TVM_GETITEMW = TV_FIRST + 62
    }
}
