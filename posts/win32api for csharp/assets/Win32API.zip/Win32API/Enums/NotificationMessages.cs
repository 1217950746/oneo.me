// ---------------------------------------------------------
// FileName: NotificationMessages.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum NotificationMessages
    {
        NM_FIRST = 0 - 0,
        NM_CUSTOMDRAW = NM_FIRST - 12,
        NM_NCHITTEST = NM_FIRST - 14
    }
}
