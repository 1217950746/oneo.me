// ---------------------------------------------------------
// FileName: ToolBarNotifications.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum ToolBarNotifications
    {
        TTN_NEEDTEXTA = 0 - 520 - 0,
        TTN_NEEDTEXTW = 0 - 520 - 10,
        TBN_QUERYINSERT = 0 - 700 - 6,
        TBN_DROPDOWN = 0 - 700 - 10,
        TBN_HOTITEMCHANGE = 0 - 700 - 13
    }
}
