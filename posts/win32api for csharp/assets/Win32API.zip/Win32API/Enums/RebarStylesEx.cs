// ---------------------------------------------------------
// FileName: RebarStylesEx.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum RebarStylesEx
    {
        RBBS_BREAK = 0x1,
        RBBS_CHILDEDGE = 0x4,
        RBBS_FIXEDBMP = 0x20,
        RBBS_GRIPPERALWAYS = 0x80,
        RBBS_USECHEVRON = 0x200
    }
}
