// ---------------------------------------------------------
// FileName: TreeViewItemFlags.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum TreeViewItemFlags
    {
        TVIF_TEXT = 0x0001,
        TVIF_IMAGE = 0x0002,
        TVIF_PARAM = 0x0004,
        TVIF_STATE = 0x0008,
        TVIF_HANDLE = 0x0010,
        TVIF_SELECTEDIMAGE = 0x0020,
        TVIF_CHILDREN = 0x0040,
        TVIF_INTEGRAL = 0x0080
    }
}
