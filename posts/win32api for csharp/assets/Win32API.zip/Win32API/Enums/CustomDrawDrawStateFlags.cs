// ---------------------------------------------------------
// FileName: CustomDrawDrawStateFlags.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum CustomDrawDrawStateFlags
    {
        CDDS_PREPAINT = 0x00000001,
        CDDS_POSTPAINT = 0x00000002,
        CDDS_PREERASE = 0x00000003,
        CDDS_POSTERASE = 0x00000004,
        CDDS_ITEM = 0x00010000,
        CDDS_ITEMPREPAINT = CDDS_ITEM | CDDS_PREPAINT,
        CDDS_ITEMPOSTPAINT = CDDS_ITEM | CDDS_POSTPAINT,
        CDDS_ITEMPREERASE = CDDS_ITEM | CDDS_PREERASE,
        CDDS_ITEMPOSTERASE = CDDS_ITEM | CDDS_POSTERASE,
        CDDS_SUBITEM = 0x00020000
    }
}
