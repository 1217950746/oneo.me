// ---------------------------------------------------------
// FileName: ToolBarExStyles.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum ToolBarExStyles
    {
        TBSTYLE_EX_DRAWDDARROWS = 0x1,
        TBSTYLE_EX_HIDECLIPPEDBUTTONS = 0x10,
        TBSTYLE_EX_DOUBLEBUFFER = 0x80
    }
}
