// ---------------------------------------------------------
// FileName: ImageListFlags.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum ImageListFlags
    {
        ILC_MASK = 0x0001,
        ILC_COLOR = 0x0000,
        ILC_COLORDDB = 0x00FE,
        ILC_COLOR4 = 0x0004,
        ILC_COLOR8 = 0x0008,
        ILC_COLOR16 = 0x0010,
        ILC_COLOR24 = 0x0018,
        ILC_COLOR32 = 0x0020,
        ILC_PALETTE = 0x0800
    }
}
