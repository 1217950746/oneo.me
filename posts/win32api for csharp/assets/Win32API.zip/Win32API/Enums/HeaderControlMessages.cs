// ---------------------------------------------------------
// FileName: HeaderControlMessages.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum HeaderControlMessages
    {
        HDM_FIRST = 0x1200,
        HDM_GETITEMRECT = HDM_FIRST + 7,
        HDM_HITTEST = HDM_FIRST + 6,
        HDM_SETIMAGELIST = HDM_FIRST + 8,
        HDM_GETITEMW = HDM_FIRST + 11,
        HDM_ORDERTOINDEX = HDM_FIRST + 15
    }
}
