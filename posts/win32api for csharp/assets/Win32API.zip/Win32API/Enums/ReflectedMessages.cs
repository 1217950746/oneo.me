// ---------------------------------------------------------
// FileName: ReflectedMessages.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum ReflectedMessages
    {
        OCM__BASE = WinMsg.WM_USER + 0x1c00,
        OCM_COMMAND = OCM__BASE + WinMsg.WM_COMMAND,
        OCM_CTLCOLORBTN = OCM__BASE + WinMsg.WM_CTLCOLORBTN,
        OCM_CTLCOLOREDIT = OCM__BASE + WinMsg.WM_CTLCOLOREDIT,
        OCM_CTLCOLORDLG = OCM__BASE + WinMsg.WM_CTLCOLORDLG,
        OCM_CTLCOLORLISTBOX = OCM__BASE + WinMsg.WM_CTLCOLORLISTBOX,
        OCM_CTLCOLORWinMsgBOX = OCM__BASE + WinMsg.WM_CTLCOLORWinMsgBOX,
        OCM_CTLCOLORSCROLLBAR = OCM__BASE + WinMsg.WM_CTLCOLORSCROLLBAR,
        OCM_CTLCOLORSTATIC = OCM__BASE + WinMsg.WM_CTLCOLORSTATIC,
        OCM_CTLCOLOR = OCM__BASE + WinMsg.WM_CTLCOLOR,
        OCM_DRAWITEM = OCM__BASE + WinMsg.WM_DRAWITEM,
        OCM_MEASUREITEM = OCM__BASE + WinMsg.WM_MEASUREITEM,
        OCM_DELETEITEM = OCM__BASE + WinMsg.WM_DELETEITEM,
        OCM_VKEYTOITEM = OCM__BASE + WinMsg.WM_VKEYTOITEM,
        OCM_CHARTOITEM = OCM__BASE + WinMsg.WM_CHARTOITEM,
        OCM_COMPAREITEM = OCM__BASE + WinMsg.WM_COMPAREITEM,
        OCM_HSCROLL = OCM__BASE + WinMsg.WM_HSCROLL,
        OCM_VSCROLL = OCM__BASE + WinMsg.WM_VSCROLL,
        OCM_PARENTNOTIFY = OCM__BASE + WinMsg.WM_PARENTNOTIFY,
        OCM_NOTIFY = OCM__BASE + WinMsg.WM_NOTIFY
    }
}
