// ---------------------------------------------------------
// FileName: ListViewMessages.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum ListViewMessages
    {
        LVM_FIRST = 0x1000,
        LVM_GETSUBITEMRECT = LVM_FIRST + 56,
        LVM_GETITEMSTATE = LVM_FIRST + 44,
        LVM_GETITEMTEXTW = LVM_FIRST + 115
    }
}
