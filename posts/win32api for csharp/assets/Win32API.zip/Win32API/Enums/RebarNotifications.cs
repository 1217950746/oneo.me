// ---------------------------------------------------------
// FileName: RebarNotifications.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum RebarNotifications
    {
        RBN_FIRST = 0 - 831,
        RBN_HEIGHTCHANGE = RBN_FIRST - 0,
        RBN_GETOBJECT = RBN_FIRST - 1,
        RBN_LAYOUTCHANGED = RBN_FIRST - 2,
        RBN_AUTOSIZE = RBN_FIRST - 3,
        RBN_BEGINDRAG = RBN_FIRST - 4,
        RBN_ENDDRAG = RBN_FIRST - 5,
        RBN_DELETINGBAND = RBN_FIRST - 6,
        RBN_DELETEDBAND = RBN_FIRST - 7,
        RBN_CHILDSIZE = RBN_FIRST - 8,
        RBN_CHEVRONPUSHED = RBN_FIRST - 10
    }
}
