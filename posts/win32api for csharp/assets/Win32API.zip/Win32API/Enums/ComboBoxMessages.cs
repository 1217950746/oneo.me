// ---------------------------------------------------------
// FileName: ComboBoxMessages.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum ComboBoxMessages
    {
        CB_GETDROPPEDSTATE = 0x0157
    }
}
