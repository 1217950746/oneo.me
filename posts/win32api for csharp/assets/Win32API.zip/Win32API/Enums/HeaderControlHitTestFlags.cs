// ---------------------------------------------------------
// FileName: HeaderControlHitTestFlags.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum HeaderControlHitTestFlags : uint
    {
        HHT_NOWHERE = 0x0001,
        HHT_ONHEADER = 0x0002,
        HHT_ONDIVIDER = 0x0004,
        HHT_ONDIVOPEN = 0x0008,
        HHT_ABOVE = 0x0100,
        HHT_BELOW = 0x0200,
        HHT_TORIGHT = 0x0400,
        HHT_TOLEFT = 0x0800
    }
}
