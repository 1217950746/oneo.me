// ---------------------------------------------------------
// FileName: RebarMessages.cs
// Author: ONEO
// Created On: 2020.10.31 23:17
// Last Modified On: 2020.10.31 23:20
// ---------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

namespace Win32API.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum RebarMessages
    {
        CCM_FIRST = 0x2000,
        WM_USER = 0x0400,
        RB_INSERTBANDA = WM_USER + 1,
        RB_DELETEBAND = WM_USER + 2,
        RB_GETBARINFO = WM_USER + 3,
        RB_SETBARINFO = WM_USER + 4,
        RB_GETBANDINFO = WM_USER + 5,
        RB_SETBANDINFOA = WM_USER + 6,
        RB_SETPARENT = WM_USER + 7,
        RB_HITTEST = WM_USER + 8,
        RB_GETRECT = WM_USER + 9,
        RB_INSERTBANDW = WM_USER + 10,
        RB_SETBANDINFOW = WM_USER + 11,
        RB_GETBANDCOUNT = WM_USER + 12,
        RB_GETROWCOUNT = WM_USER + 13,
        RB_GETROWHEIGHT = WM_USER + 14,
        RB_IDTOINDEX = WM_USER + 16,
        RB_GETTOOLTIPS = WM_USER + 17,
        RB_SETTOOLTIPS = WM_USER + 18,
        RB_SETBKCOLOR = WM_USER + 19,
        RB_GETBKCOLOR = WM_USER + 20,
        RB_SETTEXTCOLOR = WM_USER + 21,
        RB_GETTEXTCOLOR = WM_USER + 22,
        RB_SIZETORECT = WM_USER + 23,
        RB_SETCOLORSCHEME = CCM_FIRST + 2,
        RB_GETCOLORSCHEME = CCM_FIRST + 3,
        RB_BEGINDRAG = WM_USER + 24,
        RB_ENDDRAG = WM_USER + 25,
        RB_DRAGMOVE = WM_USER + 26,
        RB_GETBARHEIGHT = WM_USER + 27,
        RB_GETBANDINFOW = WM_USER + 28,
        RB_GETBANDINFOA = WM_USER + 29,
        RB_MINIMIZEBAND = WM_USER + 30,
        RB_MAXIMIZEBAND = WM_USER + 31,
        RB_GETDROPTARGET = CCM_FIRST + 4,
        RB_GETBANDBORDERS = WM_USER + 34,
        RB_SHOWBAND = WM_USER + 35,
        RB_SETPALETTE = WM_USER + 37,
        RB_GETPALETTE = WM_USER + 38,
        RB_MOVEBAND = WM_USER + 39,
        RB_SETUNICODEFORMAT = CCM_FIRST + 5,
        RB_GETUNICODEFORMAT = CCM_FIRST + 6
    }
}
